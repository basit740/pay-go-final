import React from 'react';

const Index = () => {
	return (
		<section className='max-w-6xl w-full mx-auto'>
			<h1 className='text-5xl font-medium'>About</h1>
		</section>
	);
};

export default Index;
